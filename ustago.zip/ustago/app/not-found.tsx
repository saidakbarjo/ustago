import Link from "next/link";
import { Logo } from "@/components/icons";
import { Button } from "@/components/ui/button";
export default function NotFound() {
  return (
    <div className="grid min-h-screen place-items-center bg-[radial-gradient(ellipse_at_top,#eef2ff,#fff_60%)] p-6 text-center">
      <div><Logo className="mx-auto" /><p className="mt-10 font-display text-8xl font-extrabold tracking-tight text-gradient">404</p><p className="mt-4 text-lg text-muted-foreground">Sahifa topilmadi · Страница не найдена · Page not found</p><Button asChild className="mt-8" size="lg"><Link href="/">USTAGO</Link></Button></div>
    </div>
  );
}
