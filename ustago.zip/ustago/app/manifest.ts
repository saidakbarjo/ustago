import type { MetadataRoute } from "next";
export default function manifest(): MetadataRoute.Manifest {
  return { name: "USTAGO", short_name: "USTAGO", description: "Find verified specialists in Uzbekistan", start_url: "/", display: "standalone", background_color: "#ffffff", theme_color: "#3a55ff", icons: [{ src: "/icon.svg", sizes: "any", type: "image/svg+xml" }] };
}
